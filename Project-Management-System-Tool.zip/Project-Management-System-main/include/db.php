<?php
$con = mysqli_connect("localhost", "root", "", "pms_project");
if (!$con) {
    die("not connected");
}
?>